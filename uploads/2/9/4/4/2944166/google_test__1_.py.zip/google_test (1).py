import requests
from bs4 import BeautifulSoup
while True:
    #choose = input("使用google搜尋引擎輸入g\n使用yahoo搜尋引擎輸入y\n如果要使用同樣的搜尋引擎按下enter\n\t\t-----------------------------------------------\n")
    #if choose == "g":
    #print("google搜尋引擎")
    search = input("搜尋：")
    google = requests.get("https://www.google.com/search?q="+search)
    res = google.text
    soup = BeautifulSoup(res,"html.parser")
    a_tag = soup.find_all('a')
     #,class_="BNeawe vvjwJb AP7Wnd"
    b_tag = soup.find_all('div')
    print()
    x = 1
    r = 1
    for tag in a_tag:
        b = tag.find("div")
        if "url" in tag.get("href"):
            if tag.find("div"):
                if b.string == None:
                    span_tag = tag.find("span",class_="rQMQod Xb5VRe")
                    div_tag = tag.find("div",class_="BNeawe tAd8D AP7Wnd")
                    print(x,".標題:",span_tag.text,sep="")
                    print("來源:",div_tag.string.replace("\n","\n時間:").replace(" ",""),sep="")
                    print("網址:",tag.get("href")[7:],"\n",sep="")
                else:
                    print(x,".標題:",b.string,sep="")
                    print("網址:",tag.get("href")[7:],"\n",sep="")
                x += 1
    print("\t\t-----------------------------------------------\n")
